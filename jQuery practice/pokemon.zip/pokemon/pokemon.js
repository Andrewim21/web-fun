$(document).ready(function(){
    for(var p= 0; p < 151; p++){
        $('body').append(`<img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/${i}.png">`) 
    }
});