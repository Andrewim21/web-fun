/*$(document).on('button', 'append', function(){*/

    $(document).ready(function(){
        $('.form').submit(function(){
            console.log($(this).serialize());
            return false
        });
        $('.button').click(function(){
            $('.form').submit();
            /*$('').append('<')*/
        });
    });
/*});*/