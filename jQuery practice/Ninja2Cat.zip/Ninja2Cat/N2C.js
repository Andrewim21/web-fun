$(document). ready(function(){
    $(".photo1").click(function(){
        $(".photo1").attr("src", "img/cat0.png");
    });
    $(".photo2").click(function(){
        $(".photo2").attr("src", "img/cat1.png");
    });
    $(".photo3").click(function(){
        $(".photo3").attr("src", "img/cat2.png");
    });
    $(".photo4").click(function(){
        $(".photo4").attr("src", "img/cat3.png");
    });
    $(".photo5").click(function(){
        $(".photo5").attr("src", "img/cat4.png");
    });
});